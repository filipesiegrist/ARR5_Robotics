# Biblioteca VarSpeedServo

Utilização com exemplo joystick e suporte Pan/Tilt do blog FILIPEFLOP

http://blog.filipeflop.com/motores-e-servos/controlando-micro-servo-9g-usando-joystick.html
